﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator

{
     
    public partial class Form1 : Form
    {
        public dynamic CurrentValue = "";
        public dynamic PreviousValue = "";
        public string Operat="";
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            CurrentValue= CurrentValue + button1.Text.ToString();
            textBoxOutput.Text = CurrentValue;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button2.Text.ToString();
            textBoxOutput.Text = CurrentValue;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button3.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            CurrentValue = CurrentValue + button4.Text.ToString();
            textBoxOutput.Text = CurrentValue;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button5.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }
      
        private void button6_Click_1(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button6.Text.ToString();
            textBoxOutput.Text = CurrentValue;
        }
      
        private void button7_Click_1(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button7.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button8.Text.ToString();
            textBoxOutput.Text = CurrentValue;
        }
     
        private void button9_Click_1(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button9.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }
        private void button0_Click(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button0.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }
        private void button0_Click_1(object sender, EventArgs e)
        {
            CurrentValue = CurrentValue + button0.Text.ToString();
            textBoxOutput.Text = CurrentValue;

        }


        private void textBoxOutput_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
                Operat = buttonAdd.Text;
                PreviousValue = CurrentValue;
                CurrentValue = "";
                textBoxOutput.Text = Operat;
        }
        private void buttonMinus_Click(object sender, EventArgs e)
        {
            Operat = buttonMinus.Text;
            PreviousValue = CurrentValue;
            CurrentValue = "";
            textBoxOutput.Text = Operat;
        }
        private void buttonMultiplication_Click(object sender, EventArgs e)
        {

            Operat = buttonMultiplication.Text;
            PreviousValue = CurrentValue;
            CurrentValue = "";
            textBoxOutput.Text = Operat;
        }
        private void buttonDivision_Click(object sender, EventArgs e)
        {
            Operat = buttonDivision.Text;
            PreviousValue = CurrentValue;
            CurrentValue = "";
            textBoxOutput.Text = Operat;
        }
        public string Compute(string previousValue, string Operat, string currentValue)
        {
            string Result = "";
            if (Operat == "+")
            {
                Result = (Convert.ToDecimal(previousValue) + Convert.ToDecimal(currentValue)).ToString();

            }
            else if (Operat == "-")
            {
               
                Result = (Convert.ToDecimal(previousValue) - Convert.ToDecimal(currentValue)).ToString();

            }
            else if (Operat == "*")
            {
                
                Result = (Convert.ToDecimal(previousValue) * Convert.ToDecimal(currentValue)).ToString();

            }
            else if (Operat == "/")
            {
                try {
                    
                    Result = (Convert.ToDecimal(previousValue) / Convert.ToDecimal(currentValue)).ToString();
               }
                catch (DivideByZeroException)
                {
                    
                    if(currentValue=="0" && Convert.ToDecimal(previousValue)>0)
                   {
                        Result = "Infinite";
                    }
                    else
                    {
                        Result = "-Infinite";
                    }
               }



                }

            return Result;
        }

        private void buttonEqual_Click(object sender, EventArgs e)
        {
           textBoxOutput.Text= Compute(PreviousValue, Operat, CurrentValue);
          
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxOutput.Text = "0";
            CurrentValue = "";
            PreviousValue = "";
            
        }

        private void buttonDecmialPoint_Click(object sender, EventArgs e)
        {
            if (CurrentValue.IndexOf(".") == -1)
            {
                CurrentValue = CurrentValue + buttonDecmialPoint.Text;
                textBoxOutput.Text = CurrentValue;
            }

        }
      
        private void button10_Click(object sender, EventArgs e)
        {
            CE();
           
            
        }
        public void CE()
        {
            int length = CurrentValue.Length;
            if (length > 0)
            {
                CurrentValue= CurrentValue.Remove(length - 1);
                textBoxOutput.Text = CurrentValue;
               
            }
            
        }
    }
}
