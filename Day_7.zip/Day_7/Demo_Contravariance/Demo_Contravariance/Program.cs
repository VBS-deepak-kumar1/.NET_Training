﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Contravariance
{
    internal class Program
    {
        //The following code example shows covariance and contravariance support for methods groups.N

        static object GetObject() { return null; }
        static void Setobject(object obj) { }
        static string GetString() { return ""; }
        static void SetString(string str) { }
        static void Main(string[] args)
        {
            Console.WriteLine("Contravariance delegates reverses the covariance functionality.");
            /* Covariance... A delegate specifies a return type as object ,
             but you can assign a method that returns a string.*/
            Func<object> del1 = GetString;


            /*contravariance .. A delegate specifies a parameter type as string,
            but we can assign a method that object as parameter*/
            Action<string> del2 = Setobject;
            //indexer-inbuilt generic type delegate

            Console.ReadKey();



        }
    }
}
