﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Demo_Action_delegate
{
  internal  class Program
    {
      
        static void Main(string[] args)
        {
            Action<string> messagetarget;
           if (Environment.GetCommandLineArgs().Length>1)
          
            {
                messagetarget = Display;
            }
            else
            {
                messagetarget = Console.WriteLine;
                
            }
            messagetarget("This is the else part of the condition");



        }
        private static void Display(string m)
        {
            Console.WriteLine("here we instantiating Action<T>   "+m);
        }
    }
}
