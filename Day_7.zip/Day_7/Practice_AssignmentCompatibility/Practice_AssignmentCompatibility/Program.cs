﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_AssignmentCompatibility
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Assignment Compatibility");
            string stringObject = "A String Object";
            object anObject = stringObject;
           //An object of derived class is being assigned to a variable of a base class.
          // string obj = anObject;
          // Cannot implicitly convert type 'object' to 'string'.An explicit conversion exists.
           Console.WriteLine(stringObject + "  " + anObject);
        }
    }
}
